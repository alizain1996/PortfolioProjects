import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * a class representing the statistic of the player as well as taking input from the player
 * representing their next move and whether that move is valid or not with an appropriate
 * message.
 */
public class PlayerHuman {
	
	private static final String INVALID_INPUT_MESSAGE = "Invalid number, please enter 1-8";
	private static final String IO_ERROR_MESSAGE = "I/O Error";
	private static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private Othello othello;
	private char player;
	
	/**
	 * Constructs a Player and the Othello game board.
	 * @param othello a particular othello game with game board and statistics of players.
	 * @param player the character representing the player, either P1 or P2.
	 */

	public PlayerHuman(Othello othello, char player) {
		
		this.othello = othello;
		this.player = player;
	}
	
	/**
	 * takes in the row and column the player wants to make the move at.
	 * @return displays the move made by the player on the game board.
	 */

	public Move getMove() {
		
		int row = getMove("row: ");
		int col = getMove("col: ");
		return new Move(row, col);
	}

	/**
	 * verifies if the input made by the user is valid and produces error messages if otherwise.
	 * @param message a string representation of the statistics
	 * @return an integer representing the input from the user of the row and column.
	 */
	private int getMove(String message) {
		
		int move, lower = 0, upper = 7;
		while (true) {
			try {
				System.out.print(message);
				String line = PlayerHuman.stdin.readLine();
				move = Integer.parseInt(line);
				if (lower <= move && move <= upper) {
					return move;
				} else {
					System.out.println(INVALID_INPUT_MESSAGE);
				}
			} catch (IOException e) {
				System.out.println(INVALID_INPUT_MESSAGE);
				break;
			} catch (NumberFormatException e) {
				System.out.println(INVALID_INPUT_MESSAGE);
			}
		}
		return -1;
	}
}
